const express = require("express");
const bodyParser = require("body-parser");
const app = express();


app.set('view engine', 'pug');

app.use(express.static(__dirname + '/'));

app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/bmi.html");
});

// calculation
app.post("/", function (req, res) {

    let weight = Number(req.body.weight);
    let height = Number(req.body.height)/100;
    let bmi = weight / Math.pow(height, 2);
    bmi = bmi.toFixed(2);

    //sending response to the result in bmi.html page
    res.render('bmi', {result:bmi});
});

//server listening to port 3000
app.listen(3000, function () {
    console.log("Server is running on port 3000.");
});

//need to run package bmi